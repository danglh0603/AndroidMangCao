package com.example.demo8;

import android.content.Intent;
import android.hardware.Camera;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btnDemo8);
        btn.setOnClickListener(view -> {
            accsessCamera();

        });
    }

    public void accsessCamera() {
        int cams = Camera.getNumberOfCameras(); //lấy số lượng camera
        if (cams > 0) {
            Toast.makeText(getApplicationContext(), "thiết bị có " + cams + " camera", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            this.startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "Thiết bị k có camera!", Toast.LENGTH_SHORT).show();
        }
    }
}