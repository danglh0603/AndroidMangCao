package com.example.demo8;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class MediaPlayer extends AppCompatActivity {
    private Button btnPause, btnContinue, btnStartOn;
    private ListView lstView;
    android.media.MediaPlayer mediaPlayer;
    ArrayList<String> lstName = new ArrayList<>();
    ArrayList<Uri> lstUri = new ArrayList<Uri>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_player);

        btnPause = findViewById(R.id.btnPause);
        btnContinue = findViewById(R.id.btnContinue);
        btnStartOn = findViewById(R.id.btnStartOnline);
        lstView = findViewById(R.id.lstView);

        getListRaw();// lay du lieu tu raw
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, lstName);
        lstView.setAdapter(arrayAdapter);
        lstView.setOnItemClickListener((adapterView, view, i, l) -> {
            try {
                mediaPlayer.reset();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String name = lstName.get(i);
            Uri uri2 = getRawUri(name);
            mediaPlayer = android.media.MediaPlayer.create(getApplicationContext(), uri2);
            mediaPlayer.start();
        });
        btnPause.setOnClickListener(view -> {
            try {
                mediaPlayer.pause();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        btnContinue.setOnClickListener(view -> {
            try {
                mediaPlayer.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        btnStartOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://hungnttg.github.io/aksmm.mp3";
                try {
                    mediaPlayer = android.media.MediaPlayer.create(getApplicationContext(), Uri.parse(url));
                    mediaPlayer.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public void getListRaw() {
        Field[] fields = R.raw.class.getFields();
        for (int i = 0; i < fields.length; i++) {
            lstName.add(fields[i].getName());// theem ten file nhac vao lst
            Uri uri1 = getRawUri(fields[i].getName());
            lstUri.add(uri1);
        }
    }

    public Uri getRawUri(String fileName) {
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                File.pathSeparator + File.separator + File.separator +
                getPackageName() + "/raw/" + fileName);
    }
}