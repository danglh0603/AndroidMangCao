package com.example.hotrohoctap.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hotrohoctap.DAO.DAOKhoaHoc;
import com.example.hotrohoctap.DTO.KhoaHoc;
import com.example.hotrohoctap.Fragment.KhoaHocFragment;
import com.example.hotrohoctap.R;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;

public class AdapterKhoaHoc extends RecyclerView.Adapter<AdapterKhoaHoc.ViewHolder> {

    Context context;
    DAOKhoaHoc daoKhoaHoc;
    ArrayList<KhoaHoc> list;
    KhoaHocFragment fragment;

    public AdapterKhoaHoc(Context context, KhoaHocFragment fragment, ArrayList<KhoaHoc> list) {
        this.context = context;
        this.fragment = fragment;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_khoahoc, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final KhoaHoc khoaHoc = list.get(position);
        if (khoaHoc != null) {
            holder.tvMaKh.setText(String.valueOf(khoaHoc.getMaKH()));
            holder.tvTenKH.setText("Tên khóa học: " + khoaHoc.getTenKH());
            holder.tvSoGioHoc.setText("Số giờ học: " + khoaHoc.getSoGioHoc());
            holder.btnXoa.setOnClickListener(v -> fragment.xoa(khoaHoc.getMaKH()));
            holder.cardView.setOnLongClickListener(v -> {
                fragment.update(position);
                return false;
            });
        }
    }


    @Override
    public int getItemCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private MaterialCardView cardView;
        private TextView tvMaKh;
        private AppCompatButton btnXoa;
        private TextView tvTenKH;
        private TextView tvSoGioHoc;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            tvMaKh = itemView.findViewById(R.id.tv_maKh);
            btnXoa = itemView.findViewById(R.id.btnXoa);
            tvTenKH = itemView.findViewById(R.id.tv_tenKH);
            tvSoGioHoc = itemView.findViewById(R.id.tv_soGioHoc);
        }
    }
}
