package com.example.hotrohoctap;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.hotrohoctap.Adapter.Adapter_GridView;

public class Main extends AppCompatActivity {


    GridView gridView;
    Toolbar toolbar;
    ActionBar actionBar;
    String[] name = {
            "Course",
            "Maps",
            "News",
            "Social"
    };
    int[] img = {
            R.drawable.course,
            R.drawable.map,
            R.drawable.news,
            R.drawable.social
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        gridView = findViewById(R.id.gridView);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_home_24);
        }
        if (actionBar != null) {
            actionBar.setTitle("Hỗ trợ học tập");
        }

        Adapter_GridView adapter_gridView = new Adapter_GridView(getApplicationContext(), img, name);
        gridView.setAdapter(adapter_gridView);

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            switch (position) {
                case 0: {
                    Intent in = new Intent(Main.this, Course.class);
                    startActivity(in);
                    break;
                }
                case 1: {
                    Intent in = new Intent(Main.this, MapsActivity.class);
                    startActivity(in);
                    break;
                }
                case 2: {
                    Intent in = new Intent(Main.this, News.class);
                    startActivity(in);
                    break;
                }
                case 3: {
                    Intent in = new Intent(Main.this, Social.class);
                    startActivity(in);
                    break;
                }
                default: {
                    Toast.makeText(Main.this, " ", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}