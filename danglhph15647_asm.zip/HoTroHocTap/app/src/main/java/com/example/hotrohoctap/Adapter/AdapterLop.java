package com.example.hotrohoctap.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hotrohoctap.DTO.Lop;
import com.example.hotrohoctap.Fragment.LopFragment;
import com.example.hotrohoctap.R;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;

public class AdapterLop extends RecyclerView.Adapter<AdapterLop.ViewHolder> {
    Context context;
    ArrayList<Lop> list;
    LopFragment fragment;


    public AdapterLop(Context context, LopFragment fragment, ArrayList<Lop> list) {
        this.context = context;
        this.fragment = fragment;
        this.list = list;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_lop, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Lop lop = list.get(position);
        if (lop != null) {
            holder.tvMaLop.setText(String.valueOf(lop.getMaLop()));
            holder.tvTenLop.setText("Tên lớp: " + lop.getTenLop());
            holder.btnXoa.setOnClickListener(v -> {
                fragment.xoa(lop.getMaLop());
            });
            holder.cardView.setOnLongClickListener(v -> {
                fragment.update(position);
                return false;
            });
        }
    }


    @Override
    public int getItemCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private MaterialCardView cardView;
        private TextView tvMaLop;
        private AppCompatButton btnXoa;
        private TextView tvTenLop;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            tvMaLop = itemView.findViewById(R.id.tv_maLop);
            btnXoa = itemView.findViewById(R.id.btnXoa);
            tvTenLop = itemView.findViewById(R.id.tv_tenLop);
        }
    }
}
