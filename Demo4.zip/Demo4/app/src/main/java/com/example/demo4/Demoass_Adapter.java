package com.example.demo4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class Demoass_Adapter extends BaseAdapter {
    Context context;
    int flags[];
    LayoutInflater inflater;

    public Demoass_Adapter(Context context, int[] flags) {
        this.context = context;
        this.flags = flags;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return flags.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.demogridview, null);// view root
        ImageView icon = (ImageView) convertView.findViewById(R.id.img_Item);// tham chieu dem img
        icon.setImageResource(flags[position]);// dua anh len view
        return convertView;
    }
}
