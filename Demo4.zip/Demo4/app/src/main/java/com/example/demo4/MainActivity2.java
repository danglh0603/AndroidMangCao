package com.example.demo4;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    ConnectivityManager connectivityManager;// quản lí kết nối
    NetworkInfo wifi1, i4g;
    TextView textView;
//    GridView gridView;
//    int flags[] = {
//            R.drawable.i1,
//            R.drawable.img2,
//            R.drawable.img3,
//            R.drawable.img4,
//            R.drawable.img5
//    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
//        setContentView(R.layout.demogridview);
//        gridView = findViewById(R.id.gridView);
//        Log.e("aaaaaaaaaaaaaaaaa", "onCreate: "+flags.length );
//        Demoass_Adapter adapter = new Demoass_Adapter(getApplicationContext(), flags);
//        gridView.setAdapter(adapter);


        textView = findViewById(R.id.textView);

        // 1. Sử dụng service connectivity service
        connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        // xác định loại kết nối
        wifi1 = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        i4g = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        // kiểm tra kết nối sẵn có avalable
        if (wifi1.isAvailable()) {
            textView.setText("dùng wifi");
            Log.e("aaaaaaaaaaaaaa", "onCreate: wifi");
        } else if (i4g.isAvailable()) {
            textView.setText("dùng 4g");
            Log.e("aaaaaaaaaaaaaa", "onCreate: 4g");
        }
    }
}