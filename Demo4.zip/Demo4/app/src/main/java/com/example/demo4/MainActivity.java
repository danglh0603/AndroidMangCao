package com.example.demo4;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private TextView tvKinhDo;
    private TextView tViDo;
    LocationManager locationManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvKinhDo = findViewById(R.id.tvKinhDO);
        tViDo = findViewById(R.id.tViDo);

        // 1. gọi đến service location_Seviece
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // 2. phân quyền
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        // 1s cập nhật 1 lần , khoảng cách tối thiểu 1m
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    // nghe sự thay đổi vị trí
    @Override
    public void onLocationChanged(@NonNull Location location) {
        double lat = location.getLatitude();
        double mlong = location.getLongitude();
        Log.e("aaaaaaaaaaaaaaaaaaaaaa", "onLocationChanged: "+lat+"\n"+mlong);
        tvKinhDo.setText("kinh do " + String.valueOf(mlong));
        tViDo.setText("vi do " + String.valueOf(lat));
    }
}