package com.example.demo5;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> listTitle = new ArrayList<>();//mảng lưu title
    ArrayList<String> listLink = new ArrayList<>();//mảng lưu đường dẫn
    ArrayAdapter<String> arrayAdapter;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.demoListView);
        // gọi hàm kết nối đến sever
        new RSSHauTruong().execute("https://ngoisao.net/rss/hau-truong.rss");
        // đưa lên adapter
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listTitle);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String link = listLink.get(position);// lấy vị trí của link
                intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("linkBaiViet", link);
                startActivity(intent);
            }
        });


    }

    // định nghĩa lớp nội: lấy dữ liệu từ sever
    public class RSSHauTruong extends AsyncTask<String, Void, String> {

        //1, thực thi yêu cầu từ client
        @Override
        protected String doInBackground(String... strings) {
            StringBuilder content = new StringBuilder();//kết quả trả về lưu ở stringReader
            // khai báo link đọc dữ liệu
            try {
                URL url = new URL(strings[0]);// lấy về đương link đầu tiên
                // bắt đầu đọc dữ liệu(giống java2)
                // mở kết nối và đưa dl vào string reader
                InputStreamReader reader
                        = new InputStreamReader(url.openConnection().getInputStream());
                //khai báo chuỗi kết quả
                String line = "";
                // tạo luồng đọc
                BufferedReader bufferedReader = new BufferedReader(reader);
                // cho vào vòng lặp để lấy từng thành phần dữ liệu
                while ((line = bufferedReader.readLine()) != null) { // đọc theo từng dòng
                    content.append(line);// nối các dòng line đọc được vào content
                }
                bufferedReader.close();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return content.toString();
        }

        // sau khi hàm doInBackgroud thực hiện xong và trả về content và content này đc chuyển vào s của hàm PostExecute
        //2, đưa kq lên điện thoại
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // sử dụng các hàm phân tích XML để đưa kết quả lên listView
            XMLParse xmlParse = new XMLParse();
            try {
                // tạo tài liệu mới từ chuỗi
                Document document = xmlParse.getDocument(s);
                NodeList nodeList = document.getElementsByTagName("item");
                String title = "";
                for (int i = 0; i < nodeList.getLength(); i++) {
                    Element element = (Element) nodeList.item(i);// lấy về item thứ i
                    title = xmlParse.getValue(element, "title") + " \n"; // lấy về title
                    listTitle.add(title);// lấy title đưa vào list
                    listLink.add(xmlParse.getValue(element, "link"));// lấy link đưa vào list
                }
                //cập nhật vào adapter
                arrayAdapter.notifyDataSetChanged();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            }
        }
    }
}