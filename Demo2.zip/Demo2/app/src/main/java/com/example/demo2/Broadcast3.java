package com.example.demo2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class Broadcast3 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // nhận dữ liệu
        String dl = intent.getExtras().getString("msg");
        //xử lí dữ liệu
        String km = xulidulieu(dl);
        Toast.makeText(context, km, Toast.LENGTH_SHORT).show();
    }

    private String  xulidulieu(String str) {
//        String a = str.substring(0,2);// lấy 3 kí tự đầu
        if (str.substring(0,3).equals("MEM")){
            if (str.equals("MEM537128")){
                return "khuyến mại 10%";
            }else if (str.equals("MEM537129")){
                return "khuyến mại 20%";
            }
            else {
                return "khuyến mại 10->20%";
            }
        }
        else if (str.substring(0,3).equals("VIP")){
            if (str.equals("VIP537128")){
                return "khuyến mại 30%";
            }else if (str.equals("VIP537129")){
                return "khuyến mại 40%";
            }
            else {
                return "khuyến mại 30% - 50%";
            }
        }
        else {
            return "không khuyến mại";
        }
    }
}
