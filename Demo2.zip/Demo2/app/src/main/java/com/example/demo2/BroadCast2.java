package com.example.demo2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class BroadCast2 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // nhận về tin nhắn từ hệ thống
        String msg = intent.getExtras().getString("bro");
        // thông báo cho các thành phần khác biết
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }
}
