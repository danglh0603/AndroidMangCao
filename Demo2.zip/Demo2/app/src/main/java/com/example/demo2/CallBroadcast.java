package com.example.demo2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class CallBroadcast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // lớp quản lí cuộc gọi
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        MyPhoneState phoneState = new MyPhoneState(context);
        telephonyManager.listen(phoneState,PhoneStateListener.LISTEN_CALL_STATE);
    }

    // tạo class quản lí cuộc gọi
    public class MyPhoneState extends PhoneStateListener{
        Context context;
        public MyPhoneState(Context context){
            this.context = context;
        }
        // báo khi có cuộc gọi đến

        @Override
        public void onCallStateChanged(int state, String phoneNumber) {
            if (state==1){
                Toast.makeText(context, "Có người gọi đến: "+phoneNumber, Toast.LENGTH_SHORT).show();
            }
            super.onCallStateChanged(state, phoneNumber);
        }
    }
}
