package com.ph15647.danglhph15647_androidnc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ph15647.danglhph15647_androidnc.R;
import com.ph15647.danglhph15647_androidnc.ph15647_SanPham;
import com.ph15647.danglhph15647_androidnc.ph15647_SumDk;

import java.util.ArrayList;

public class ph15647_Adapter_Cau4 extends ArrayAdapter<ph15647_SanPham> {

    ArrayList<ph15647_SanPham> list;
//    ph15647_DAOSp daoSp;
    private TextView tvma;
    private TextView tvsl;


    public ph15647_Adapter_Cau4(@NonNull Context context, ArrayList<ph15647_SanPham> list) {
        super(context, 0, list);
        this.list = list;
        //DAOSp = new DAOSp(context);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ph15647_adapter_cau4, null);
        tvma = view.findViewById(R.id.tvma);
        tvsl = view.findViewById(R.id.tvsl);
        ph15647_SanPham sanPham = list.get(position);
        if (sanPham != null) {
//            tvmaTl.setText("ma the loai: " + sumDk.getMatl());
//            tvslXuat.setText("so luong xuat: " + sumDk.getSoluong());

        }

        return view;
    }
}
