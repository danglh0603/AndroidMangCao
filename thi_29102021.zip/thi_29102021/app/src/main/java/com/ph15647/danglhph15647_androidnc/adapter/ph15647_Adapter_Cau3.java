package com.ph15647.danglhph15647_androidnc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ph15647.danglhph15647_androidnc.R;
import com.ph15647.danglhph15647_androidnc.ph15647_SumDk;

import java.util.ArrayList;

public class ph15647_Adapter_Cau3 extends ArrayAdapter<ph15647_SumDk> {

    ArrayList<ph15647_SumDk> list;
    //DAOSp DAOSp;
    private TextView tvma;
    private TextView tvsl;


    public ph15647_Adapter_Cau3(@NonNull Context context, ArrayList<ph15647_SumDk> list) {
        super(context, 0, list);
        this.list = list;
        //DAOSp = new DAOSp(context);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ph15647_adapter_cau3, null);

        tvma = view.findViewById(R.id.tvma);
        tvsl = view.findViewById(R.id.tvsl);
        ph15647_SumDk sumDk = list.get(position);
        if (sumDk != null) {
//            tvmaSp.setText("ma sp: " + sumDk.getMaSp());
//            tvslNhap.setText("so luong: " + sumDk.getSlNhap());

        }

        return view;
    }
}
