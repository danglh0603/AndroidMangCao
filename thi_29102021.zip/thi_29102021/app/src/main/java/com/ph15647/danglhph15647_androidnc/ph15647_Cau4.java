package com.ph15647.danglhph15647_androidnc;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class ph15647_Cau4 extends AppCompatActivity {

    private EditText edNam;
    private Button btnLoc;
    private ListView lstView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ph15647_cau4);

        edNam = findViewById(R.id.edNam);
        btnLoc = findViewById(R.id.btnLoc);
        lstView = findViewById(R.id.lstView);
    }
}