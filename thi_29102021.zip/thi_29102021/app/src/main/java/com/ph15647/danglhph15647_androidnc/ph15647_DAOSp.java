package com.ph15647.danglhph15647_androidnc;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ph15647_DAOSp {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    SQLiteDatabase database;
    DatabaseSP db;

    public ph15647_DAOSp(Context context) {
        db = new DatabaseSP(context);
        database = db.getWritableDatabase();
    }

    public void insert(String mtl, String msp, int sln, int slx, String dgn, String dgx, String nn, String nx) {
        ContentValues values = new ContentValues();
        values.put("matl", mtl);

        ContentValues values1 = new ContentValues();
        values1.put("masp", msp);
        values1.put("matl", msp);
        values1.put("slnhap", sln);
        values1.put("dgnhap", dgn);
        values1.put("ngaynhap", nn);

        ContentValues values2 = new ContentValues();
        values2.put("masp", msp);
        values2.put("ngayxuat", nx);

        ContentValues values3 = new ContentValues();
        values3.put("masp", msp);
        values3.put("slxuat", slx);
        values3.put("dgxuat", dgx);

        database.insert("THELOAI", null, values);
        database.insert("SANPHAM", null, values1);
        database.insert("HOADON", null, values2);
        database.insert("HDCT", null, values3);
    }

    @SuppressLint("Range")
    public ArrayList<ph15647_SanPham> getListSp() {
        ArrayList<ph15647_SanPham> list = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT* FROM SANPHAM", null);
        while (cursor.moveToNext()) {
            ph15647_SanPham sanPham = new ph15647_SanPham();
            sanPham.setMatl(cursor.getColumnName(cursor.getColumnIndex("matl")));
            sanPham.setDgn(cursor.getColumnName(cursor.getColumnIndex("dgnhap")));
            sanPham.setMsp(cursor.getColumnName(cursor.getColumnIndex("masp")));
            try {
                sanPham.setNn(sdf.parse(cursor.getColumnName(cursor.getColumnIndex("ngaynhap"))
                ));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            sanPham.setSln(Integer.parseInt(cursor.getColumnName(cursor.getColumnIndex("slnhap"))));

            list.add(sanPham);

        }
        return list;
    }
}
