package com.ph15647.danglhph15647_androidnc;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.ph15647.danglhph15647_androidnc.adapter.ph15647_adapter_DsSp;

import java.util.ArrayList;

public class ph15647_DsSanPham extends AppCompatActivity {

    ph15647_adapter_DsSp adapter_dsSp;
    ph15647_DAOSp daoSp;
    ArrayList<ph15647_SanPham> list;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ph15647_ds_san_pham);
        listView = findViewById(R.id.lstV);

        daoSp = new ph15647_DAOSp(getApplicationContext());
        list = daoSp.getListSp();
        adapter_dsSp = new ph15647_adapter_DsSp(getApplicationContext(), list);
        listView.setAdapter(adapter_dsSp);


    }
}