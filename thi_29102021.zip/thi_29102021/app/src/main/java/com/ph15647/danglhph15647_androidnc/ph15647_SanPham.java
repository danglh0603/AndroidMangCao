package com.ph15647.danglhph15647_androidnc;

import java.util.Date;

public class ph15647_SanPham {
    String msp;
    String matl;
    int sln;
    String dgn;
    Date nn;

    public String getMsp() {
        return msp;
    }

    public void setMsp(String msp) {
        this.msp = msp;
    }

    public String getMatl() {
        return matl;
    }

    public void setMatl(String matl) {
        this.matl = matl;
    }

    public int getSln() {
        return sln;
    }

    public void setSln(int sln) {
        this.sln = sln;
    }

    public String getDgn() {
        return dgn;
    }

    public void setDgn(String dgn) {
        this.dgn = dgn;
    }

    public Date getNn() {
        return nn;
    }

    public void setNn(Date nn) {
        this.nn = nn;
    }

    public ph15647_SanPham() {
    }

    public ph15647_SanPham(String msp, String matl, int sln, String dgn, Date nn) {
        this.msp = msp;
        this.matl = matl;
        this.sln = sln;
        this.dgn = dgn;
        this.nn = nn;
    }
}
