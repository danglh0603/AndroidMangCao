package com.ph15647.danglhph15647_androidnc;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseSP extends SQLiteOpenHelper {
    public DatabaseSP(@Nullable Context context) {
        super(context, "data.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE THELOAI(" +
                "matl text," +
                "tentl text)");
        sqLiteDatabase.execSQL("CREATE TABLE SANPHAM(" +
                "masp TEXT," +
                "matl text," +
                "tensp text," +
                "slnhap INTEGER," +
                "dgnhap TEXT," +
                "ngaynhap DATE)");
        sqLiteDatabase.execSQL("CREATE TABLE HOADON(" +
                "mahd TEXT," +
                "masp text," +
                "tenkhachhang text," +
                "ngayxuat DATE)");
        sqLiteDatabase.execSQL("CREATE TABLE HDCT(" +
                "mahdct text," +
                "masp text," +
                "slxuat integer," +
                "dgxuat TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
