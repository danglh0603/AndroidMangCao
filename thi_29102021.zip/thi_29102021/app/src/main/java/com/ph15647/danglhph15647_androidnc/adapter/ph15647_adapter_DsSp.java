package com.ph15647.danglhph15647_androidnc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ph15647.danglhph15647_androidnc.R;
import com.ph15647.danglhph15647_androidnc.ph15647_SanPham;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ph15647_adapter_DsSp extends ArrayAdapter<ph15647_SanPham> {

    ArrayList<ph15647_SanPham> list;
    //DAOSp DAOSp;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private TextView tvmasp;
    private TextView tvmal;
    private TextView tvslnhap;
    private TextView tvdgnhap;
    private TextView tvngaynhap;



    public ph15647_adapter_DsSp(@NonNull Context context, ArrayList<ph15647_SanPham> list) {
        super(context, 0, list);
        this.list = list;
        //DAOSp = new DAOSp(context);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ph15647_adapter_itemlist, null);

        tvmasp = view.findViewById(R.id.tvmasp);
        tvmal = view.findViewById(R.id.tvmal);
        tvslnhap = view.findViewById(R.id.tvslnhap);
        tvdgnhap = view.findViewById(R.id.tvdgnhap);
        tvngaynhap = view.findViewById(R.id.tvngaynhap);
        ph15647_SanPham sanPham = list.get(position);
        if (sanPham != null) {
            tvmal.setText("ma loai: " + sanPham.getMatl());
            tvmasp.setText("ma sp: " + sanPham.getMsp());
            tvslnhap.setText("so luong nhap: " + sanPham.getSln());
            tvdgnhap.setText("don gia nhap: " + sanPham.getDgn());
            tvngaynhap.setText("ngay nhap: " + sdf.format(sanPham.getNn()));
        }

        return view;
    }
}
