package com.ph15647.danglhph15647_androidnc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ph15647_main extends AppCompatActivity {

    private EditText edmaLoai;
    private EditText edmaSp;
    private EditText edslNhap;
    private EditText edslXuat;
    private EditText eddgNhap;
    private EditText eddgXuat;
    private EditText edngayNhap;
    private EditText edngayXuat;
    private Button btnthem;
    private Button btnList;
    private Button btnsumNhap;
    private Button btnC4;
    ph15647_DAOSp daoSp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ph15647_main);

        edmaLoai = findViewById(R.id.edmaLoai);
        edmaSp = findViewById(R.id.edmaSp);
        edslNhap = findViewById(R.id.edslNhap);
        edslXuat = findViewById(R.id.edslXuat);
        eddgNhap = findViewById(R.id.eddgNhap);
        eddgXuat = findViewById(R.id.eddgXuat);
        edngayNhap = findViewById(R.id.edngayNhap);
        edngayXuat = findViewById(R.id.edngayXuat);
        btnthem = findViewById(R.id.btnthem);
        btnList = findViewById(R.id.btnList);
        btnsumNhap = findViewById(R.id.btnsumNhap);
        btnC4 = findViewById(R.id.btnsumXuat);

        daoSp = new ph15647_DAOSp(getApplicationContext());
        btnthem.setOnClickListener(v -> {
            String mtl = edmaLoai.getText().toString();
            String msp = edmaSp.getText().toString();
            int sln = Integer.parseInt(edslNhap.getText().toString());
            int slx = Integer.parseInt(edslXuat.getText().toString());
            String dgn = eddgNhap.getText().toString();
            String dgx = eddgXuat.getText().toString();
            String nn = edngayNhap.getText().toString();
            String nx = edngayXuat.getText().toString();

            daoSp.insert(mtl, msp, sln, slx, dgn, dgx, nn, nx);
            Toast.makeText(getApplicationContext(), "Them thanh cong!", Toast.LENGTH_SHORT).show();
        });
        btnList.setOnClickListener(v -> {
            Intent in = new Intent(ph15647_main.this, ph15647_DsSanPham.class);
            startActivity(in);
        });
        btnsumNhap.setOnClickListener(v -> {
            Intent in = new Intent(ph15647_main.this, ph15647_Cau3.class);
            startActivity(in);
        });
        btnC4.setOnClickListener(v -> {
            Intent in = new Intent(ph15647_main.this, ph15647_Cau4.class);
            startActivity(in);
        });

    }
}