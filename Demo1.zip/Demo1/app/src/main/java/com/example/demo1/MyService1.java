package com.example.demo1;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService1 extends Service {
    // sử dụng dữ liệu từ app khác
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    //
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("TAG", "onCreate: onCreate được gọi ");
        Toast.makeText(this, "Oncreate được gọi", Toast.LENGTH_SHORT).show();
    }

    // thực hiện chức năng chính của service
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("TAG", "onStart: onStart được gọi ");
        Toast.makeText(this, "onStart được gọi", Toast.LENGTH_SHORT).show();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("TAG", "onDestroy: onDestroy được gọi ");
        Toast.makeText(this, "onDestroy được gọi", Toast.LENGTH_SHORT).show();

    }
}
