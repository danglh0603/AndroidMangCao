package com.example.demo1;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService2 extends IntentService {
    Bundle bundle;
    String chuoi;
    int count = 0;

    public MyService2() {
        super("MyService2");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // hàm lấy dữ liệu truyền vào service
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        char c1 = intent.getCharExtra("abc", '0');// lấy dl dạng kí tự
        String text = intent.getStringExtra("abc1");//lấy dl dạng chuỗi
        // đếm
        Log.e("TAG", c1+"///"+text );
        count = countChar(text, c1);
        Log.e("TAG", ""+count );
        Toast.makeText(this, c1 +" : " + String.valueOf(count), Toast.LENGTH_LONG).show();


    }
    //viết hàm tính tổng các kí tự
    public int countChar(String str, char c) {
        int count = 0;
        for (int i=0; i<str.length();i++){
            if (str.charAt(i)==c){// nếu vị trí có kí tự là c
                count++;
            }
        }
        return count;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("TAG", "onDestroy: onDestroy được gọi ");
        Toast.makeText(this, "onDestroy được gọi", Toast.LENGTH_SHORT).show();

    }
}
