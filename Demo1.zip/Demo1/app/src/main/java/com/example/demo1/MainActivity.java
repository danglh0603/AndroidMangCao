package com.example.demo1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    // phải khai báo sevice trong manifest và cấp quyền internet
    Button btnStart, btnStop;
    EditText txt1, txt2;
    Intent intent, intent2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        setContentView(R.layout.test);


        btnStart = findViewById(R.id.btnstart);
        btnStop = findViewById(R.id.btnstop);
        txt1 = findViewById(R.id.edt);
        txt2 = findViewById(R.id.edt2);
        intent = new Intent(this,MyService1.class);
        intent2 = new Intent(this,MyService2.class);
    }

    public void khoiTaoSevice(View view) {
        // lấy gt dl nhập vào text
        String input = txt1.getText().toString();
        //chuyển đổi thành mảng kí tự
        char [] c = input.toCharArray();
        // truyền kí tự đầu tiên của mảng
        intent2.putExtra("abc",c[0]);
        // truyền text 2
        intent2.putExtra("abc1",txt2.getText().toString());
        //
        startService(intent2);
    }
    public void dungSevice(View view) {
        stopService(intent2);
    }
}