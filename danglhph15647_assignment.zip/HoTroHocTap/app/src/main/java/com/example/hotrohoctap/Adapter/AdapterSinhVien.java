package com.example.hotrohoctap.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hotrohoctap.DAO.DAOKhoaHoc;
import com.example.hotrohoctap.DAO.DAOLop;
import com.example.hotrohoctap.DTO.KhoaHoc;
import com.example.hotrohoctap.DTO.Lop;
import com.example.hotrohoctap.DTO.SinhVien;
import com.example.hotrohoctap.Fragment.SinhVienFragment;
import com.example.hotrohoctap.R;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;

public class AdapterSinhVien extends RecyclerView.Adapter<AdapterSinhVien.ViewHodler> {
    private final Context context;
    private final ArrayList<SinhVien> list;
    private final SinhVienFragment fragment;
    DAOLop daoLop;
    DAOKhoaHoc daoKhoaHoc;

    public AdapterSinhVien(Context context, SinhVienFragment fragment, ArrayList<SinhVien> list) {

        this.context = context;
        this.fragment = fragment;
        this.list = list;
    }


    @NonNull
    @Override
    public ViewHodler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.adapter_sinhvien, null);
        return new ViewHodler(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHodler holder, int position) {
        final SinhVien sinhVien = list.get(position);
        if (sinhVien != null) {
            holder.tvMasV.setText(String.valueOf(sinhVien.getMaSv()));
            holder.tvTenSv.setText("Tên sinh viên: " + sinhVien.getTenSv());
            daoLop = new DAOLop(context);
            Lop lop = daoLop.getID(sinhVien.getMaLop());
            holder.tvTenLop.setText("Lớp: " + lop.getTenLop());
            daoKhoaHoc = new DAOKhoaHoc(context);
            KhoaHoc khoaHoc = daoKhoaHoc.getID(sinhVien.getMaKH());
            holder.tvTenKH.setText("Khóa học: " + khoaHoc.getTenKH());
            holder.tvNamSinh.setText("Năm sinh: " + sinhVien.getNamSinh());
            holder.btnXoa.setOnClickListener(v -> {
                fragment.xoa(sinhVien.getMaSv());
            });
            holder.cardView.setOnLongClickListener(v -> {
                fragment.update(position);
                return false;
            });
        }

    }

    @Override
    public int getItemCount() {
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    class ViewHodler extends RecyclerView.ViewHolder {
        private TextView tvMasV;
        private AppCompatButton btnXoa;
        private TextView tvTenSv;
        private TextView tvTenLop;
        private TextView tvTenKH;
        private TextView tvNamSinh;
        private MaterialCardView cardView;


        public ViewHodler(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            tvMasV = itemView.findViewById(R.id.tv_masV);
            btnXoa = itemView.findViewById(R.id.btnXoa);
            tvTenSv = itemView.findViewById(R.id.tv_tenSv);
            tvTenLop = itemView.findViewById(R.id.tv_tenLop);
            tvTenKH = itemView.findViewById(R.id.tv_tenKH);
            tvNamSinh = itemView.findViewById(R.id.tv_namSinh);
        }
    }
}
