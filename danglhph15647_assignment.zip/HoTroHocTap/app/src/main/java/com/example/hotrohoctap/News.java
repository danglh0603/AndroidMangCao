package com.example.hotrohoctap;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.hotrohoctap.XMLParse.XMLParse;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class News extends AppCompatActivity {

    Toolbar toolbar;
    ActionBar actionBar;
    ListView lstView;
    ArrayList<String> lstTitle = new ArrayList<>();
    ArrayList<String> lstLink = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        toolbar = findViewById(R.id.toolbar);
        lstView = findViewById(R.id.lstNews);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        if (actionBar != null) {
            actionBar.setTitle("News");
        }
        getData();
    }

    private void getData() {
        new NewsFeed().execute("https://giaoducthoidai.vn/rss/giao-duc.rss");
        arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, lstTitle);
        lstView.setAdapter(arrayAdapter);
        lstView.setOnItemClickListener((parent, view, position, id) -> {
            String link = lstLink.get(position);
            intent = new Intent(News.this, News2.class);
            intent.putExtra("link", link);
            startActivity(intent);
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public class NewsFeed extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            StringBuilder content = new StringBuilder();
            try {
                URL url = new URL(strings[0]);
                InputStreamReader reader
                        = new InputStreamReader(url.openConnection().getInputStream());
                String line = "";
                BufferedReader bufferedReader = new BufferedReader(reader);
                while ((line = bufferedReader.readLine()) != null) {
                    content.append(line);
                }
                bufferedReader.close();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return content.toString();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            XMLParse xmlParse = new XMLParse();
            try {
                Document document = xmlParse.getDocument(s);
                NodeList nodeList = document.getElementsByTagName("item");
                String title = "";
                String link = "";
                for (int i = 0; i < nodeList.getLength(); i++) {
                    Element element = (Element) nodeList.item(i);
                    title = xmlParse.getValue(element, "title");
                    link = xmlParse.getValue(element, "link");

                    lstTitle.add(title);
                    lstLink.add(link);
                }
                arrayAdapter.notifyDataSetChanged();

            } catch (SAXException | IOException e) {
                e.printStackTrace();
            }
        }
    }
}