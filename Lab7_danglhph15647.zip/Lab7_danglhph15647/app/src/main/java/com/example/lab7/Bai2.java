package com.example.lab7;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Bai2 extends AppCompatActivity {

    private ImageView imgAll;
    private Button btnNext;
    private TextView tvName;


    private ArrayList<String> lst = new ArrayList<>();
    int index = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        imgAll = findViewById(R.id.imgAll);
        tvName = findViewById(R.id.tvName);
        btnNext = findViewById(R.id.btn_Next);


        lst.add(0, "All");
        lst.add(1, "Doraemon");
        lst.add(2, "Nobita");
        lst.add(3, "Shizuka");
        lst.add(4, "Chaien");
        lst.add(5, "Suneo");


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (index == lst.size()) {
                    index = 0;
                }
                String name = lst.get(index);
                showImg(name);
                showTextView(name);
                index++;
            }
        });

    }

    private void showTextView(String name) {

        // ẩn img chạy từ trái sang phải làm mờ alpha = 1 đến alpha = 0
        ObjectAnimator animator1 = ObjectAnimator.ofFloat(tvName, "translationX", 0, -500f);
        animator1.setDuration(2000);
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(tvName, "alpha", 1f, 0f);
        animator2.setDuration(2000);

        // hiện img ngược lại ẩn img
        ObjectAnimator animator3 = ObjectAnimator.ofFloat(tvName, "translationX", 500f, 0f);
        animator3.setDuration(2000);
        ObjectAnimator animator4 = ObjectAnimator.ofFloat(tvName, "alpha", 0f, 1f);
        animator4.setDuration(2000);

        // thứ tự chạy animation
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(animator3).with(animator4).after(animator1).after(animator2);
        animatorSet.start();
        final String imgName = name;
        //
        animator2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if (imgName == "All") {
                    tvName.setText("All");
                }
                if (imgName == "Doraemon") {
                    tvName.setText("Doraemon");
                }
                if (imgName == "Nobita") {
                    tvName.setText("Nobita");
                }
                if (imgName == "Shizuka") {
                    tvName.setText("Shizuka");
                }
                if (imgName == "Chaien") {
                    tvName.setText("Chaien");
                }
                if (imgName == "Suneo") {
                    tvName.setText("Suneo");
                }

            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }
        });
    }

    private void showImg(String img) {
        // ẩn img chạy từ trái sang phải làm mờ alpha = 1 đến alpha = 0
        ObjectAnimator animator1 = ObjectAnimator.ofFloat(imgAll, "translationX", 0f, 500f);
        animator1.setDuration(2000);
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(imgAll, "alpha", 1f, 0f);
        animator2.setDuration(2000);

        // hiện img ngược lại ẩn img
        ObjectAnimator animator3 = ObjectAnimator.ofFloat(imgAll, "translationX", -500f, 0f);
        animator3.setDuration(2000);
        ObjectAnimator animator4 = ObjectAnimator.ofFloat(imgAll, "alpha", 0f, 1f);
        animator4.setDuration(2000);

        // thứ tự chạy animation
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(animator3).with(animator4).after(animator1).after(animator2);
        animatorSet.start();
        final String imgName = img;
        //
        animator2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if (imgName == "All") {
                    imgAll.setImageResource(R.drawable.all);
                }
                if (imgName == "Doraemon") {
                    imgAll.setImageResource(R.drawable.doraemon);
                }
                if (imgName == "Nobita") {
                    imgAll.setImageResource(R.drawable.nobita);
                }
                if (imgName == "Shizuka") {
                    imgAll.setImageResource(R.drawable.shizuka);
                }
                if (imgName == "Chaien") {
                    imgAll.setImageResource(R.drawable.chaien);
                }
                if (imgName == "Suneo") {
                    imgAll.setImageResource(R.drawable.suneo);
                }

            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }
        });
    }
}