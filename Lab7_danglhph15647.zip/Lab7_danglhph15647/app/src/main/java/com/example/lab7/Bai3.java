package com.example.lab7;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Bai3 extends AppCompatActivity {
    private ImageView imgHour;
    private ImageView imgMinute;
    private ImageView imgSecond;
    private Button btnRun;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);

        imgHour = findViewById(R.id.imgHour);
        imgMinute = findViewById(R.id.imgMinute);
        imgSecond = findViewById(R.id.imgSecond);
        btnRun = findViewById(R.id.btn_Run);
        btnRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                runClock();
            }
        });
    }

    public void runClock() {
        Animation hour = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.clock_hour);
        imgHour.startAnimation(hour);
        Animation minute = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.clock_munite);
        imgMinute.startAnimation(minute);
        Animation second = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.clock_second);
        imgSecond.startAnimation(second);
    }


}