package com.example.lab7;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Bai1 extends AppCompatActivity {
    ImageView imgBai1;
    Button btnRotation, btnMoving, btnZoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);


        imgBai1 = findViewById(R.id.imgBai1);
        btnRotation = findViewById(R.id.btn_Rotation);
        btnMoving = findViewById(R.id.btn_Moving);
        btnZoom = findViewById(R.id.btn_Zoom);
        AnimationB1();

    }

    public void AnimationB1() {
        // rotation
        btnRotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int dest = 360;
                if (imgBai1.getRotation() == 360) {
                    System.out.println(imgBai1.getAlpha());
                    dest = 0;
                }
                ObjectAnimator animator = new ObjectAnimator().ofFloat(imgBai1, "rotation", dest);
                animator.setDuration(2000);
                animator.start();
            }
        });

        // moving
        btnMoving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.moving);
                imgBai1.startAnimation(animation);

            }
        });

        // zoom
        btnZoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoom);
                imgBai1.startAnimation(animation);
            }
        });
    }


}