package com.example.lab7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
// LÊ HẢI ĐĂNG - PH15647
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void bai1(View view) {
        Intent in = new Intent(MainActivity.this, Bai1.class);
        startActivity(in);
    }

    public void bai2(View view) {
        Intent in = new Intent(MainActivity.this, Bai2.class);
        startActivity(in);
    }

    public void bai3(View view) {
        Intent in = new Intent(MainActivity.this, Bai3.class);
        startActivity(in);
    }
}