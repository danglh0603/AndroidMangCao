package com.example.demo3;

import android.Manifest;
import android.content.CursorLoader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.lstView);
        if (requestPermission() == true) {
            readContact();
            accrsMedia();
        }
    }

    public void accrsMedia() {
        String[] prs = {
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
        };
        // tạo con trỏ
        CursorLoader cursorLoader =
                new CursorLoader(this, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, prs,
                        null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();
        cursor.moveToFirst();
        String s = "";
        while (!cursor.isAfterLast()) {
            for (int i = 0; i < cursor.getCount(); i++) {
                s += cursor.getString(i) + " - ";

            }
            s += "\n";
            cursor.moveToNext();
        }
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();

    }

    public void readContact() {
        Uri uri = Uri.parse("content://contact/people"); // đường dẫn truy xuất contact
        ArrayList<String> list = new ArrayList<>(); // tạo bảng để lưu contact
        CursorLoader cursorLoader = new CursorLoader(this, uri, null, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();
        cursor.moveToFirst();// di chuyển về vị trí đầu tiên
        while (!cursor.isAfterLast()) {
            String s = "";
            String idColumName = ContactsContract.Contacts._ID;
            int index = cursor.getColumnIndex(idColumName); // lấy thứ tự bản ghi
            s += cursor.getString(index) + " - ";// lấy về thứ tự r đưa vào chuỗi

            String nameColumName = ContactsContract.Contacts.DISPLAY_NAME;// lấy tên người dùng
            int nameIndex = cursor.getColumnIndex(nameColumName);
            s += cursor.getString(nameIndex) + " - ";

            cursor.moveToNext();
            list.add(s);
        }
        cursor.close();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);
    }

    public boolean requestPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.WRITE_CONTACTS)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.d("TAG", "requestPermission: đã được gán");
                return true;
            }
            // neu chua dc gan hien thi thong bao xin quyen
            else {
                Log.d("aaaaa", "requestPermission: xin quyen");
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{
                                Manifest.permission.READ_CONTACTS,
                                Manifest.permission.WRITE_CONTACTS,
                                Manifest.permission.ACCESS_MEDIA_LOCATION

                        }, 1);
                return false;
            }
        } else {
            return true;
        }
    }
}