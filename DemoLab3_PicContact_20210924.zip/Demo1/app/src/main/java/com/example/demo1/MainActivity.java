package com.example.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.QuickContactBadge;
//MSSV: PH0001
//TenSV: Nguyen Van a
public class MainActivity extends AppCompatActivity {
    Button btnStart, btnStop;
    EditText txt1,txt2;
    Intent intent1,intent2,intent3,intent4,intent5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnStart = findViewById(R.id.btn1);
        btnStop = findViewById(R.id.btn2);
        txt1 = findViewById(R.id.editText1);
        txt2 = findViewById(R.id.editText2);
        intent1 = new Intent(this,MyService1.class);
        intent2 = new Intent(this,MyService2.class);
        intent3 = new Intent(this,MyService3.class);
        intent4 = new Intent(this,MyService4.class);
        intent5 = new Intent(this,MyService5.class);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                //startService(intent1);
//                //lay du lieu-> dua vao intent-> startService
//                String masv = txt1.getText().toString();
//                String tensv = txt2.getText().toString();
//                intent2.putExtra("masv",masv);
//                intent2.putExtra("tensv",tensv);
//                startService(intent2);

//                //lay ve ky tu nhap vao
//                String inputChar = txt1.getText().toString();
//                char[] c = inputChar.toCharArray();//chuyển chuỗi thành mảng ký tự
//                //lấy chuỗi nhập vào
//                String check = txt2.getText().toString();
//                intent3.putExtra("char",c[0]);//truyn ky tu
//                intent3.putExtra("check",check);//truyen chuoi
//                startService(intent3);
//
//                String sogiay = txt1.getText().toString();
//                intent4.putExtra("second", Long.parseLong(sogiay));
//                startService(intent4);

                String masv = txt1.getText().toString();
                String tensv = txt2.getText().toString();
                //dua du lieu vao intent
                intent5.putExtra("masv",masv);
                intent5.putExtra("tensv",tensv);
                //truyen du lieu cho service
                startService(intent5);

            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //stopService(intent1);
                //stopService(intent2);
                stopService(intent5);
            }
        });

    }


}
