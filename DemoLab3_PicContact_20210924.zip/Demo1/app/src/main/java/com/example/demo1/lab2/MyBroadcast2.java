package com.example.demo1.lab2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyBroadcast2 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //1.nhanj thong tin
        String msg = intent.getExtras().getString("broad");
        //2. dua ra thong bao
        Toast.makeText(context,msg,Toast.LENGTH_LONG).show();
    }
}
