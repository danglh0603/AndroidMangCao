package com.example.demo1.lab2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class MyBroadcast1 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //nhan va xu ly du lieu
        //1. Goi service xu ly
        TelephonyManager telephonyManager=(TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        //2. Tao doi tuong moi
        MyPhoneState myPhoneState = new MyPhoneState(context);
        //3. goi phuong thuc lang nghe
        telephonyManager.listen(myPhoneState,PhoneStateListener.LISTEN_CALL_STATE);
    }
    //dinh nghia lop lang nghe cuoc goi den
    public class MyPhoneState extends PhoneStateListener{
        Context context;

        public MyPhoneState(Context context) {
            this.context = context;
        }
        //ham lang nghe cuoc goi den


        @Override
        public void onCallStateChanged(int state, String phoneNumber) {
            if(state==1)//co cuoc goi den
            {
                Toast.makeText(context,"Ban co cuoc goi den tu: "+phoneNumber,Toast.LENGTH_LONG).show();
            }
            super.onCallStateChanged(state, phoneNumber);
        }
    }
}
