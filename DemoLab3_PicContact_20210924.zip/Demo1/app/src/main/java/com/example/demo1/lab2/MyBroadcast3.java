package com.example.demo1.lab2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyBroadcast3 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //nhan vao chuoi can xu ly
        String msg = intent.getExtras().getString("broad");
        String kq = xuLyChuoi(msg);//xu ly va tra ve ket qua
        Toast.makeText(context,kq,Toast.LENGTH_LONG).show();//dua ra thong bao
    }
    public String xuLyChuoi(String str)
    {
        if(str.substring(0,3).equals("MEM"))
        {
            if(str.equals("MEM537128"))
            {
                return "Khuyen mai 10%";
            }
            else if(str.equals("MEM537129"))
            {
                return "Khuyen mai 20%";
            }
            else
            {
                return "Khuyen mai tu 10%->20%";
            }
        }
        else if(str.substring(0,3).equals("VIP"))
        {
            if(str.equals("VIP537128"))
            {
                return "Khuyen mai 30%";
            }
            else if(str.equals("VIP537129"))
            {
                return "Khuyen mai 50%";
            }
            else
            {
                return "Khuyen mai tu 30%->50%";
            }
        }
        else {
            return "Khong khuyen mai";
        }
    }

}
