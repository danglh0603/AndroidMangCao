package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.example.demo1.R;

public class Demo21Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main3);
        codePhanQuyen();
        Intent intent = new Intent(this,MyBroadcast1.class);
        sendBroadcast(intent);
    }
    //code phan quyen
    public boolean codePhanQuyen()
    {
        if(Build.VERSION.SDK_INT>=23)
        {
            //neu quyen read_phone_state da duoc gan
            //va quyen READ_PHONE_NUMBERS da duoc gan
            if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
            == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS)
            ==PackageManager.PERMISSION_GRANTED)
            {
                return true;
            }
            else
            {//neu chua co quyen thi hien thi thong bao de nguoi dung cap quyen
                ActivityCompat.requestPermissions(Demo21Main2Activity.this,
                        new String[]{Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_PHONE_NUMBERS},1);
                return false;
            }
        }
        else
        {
            Log.d("TAG","Quyen da duoc gan");
            return true;
        }
    }
}
