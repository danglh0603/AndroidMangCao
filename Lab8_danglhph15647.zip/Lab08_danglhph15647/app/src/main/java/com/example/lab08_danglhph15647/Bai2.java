package com.example.lab08_danglhph15647;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class Bai2 extends AppCompatActivity {

    private Button btnPrev;
    private Button btnPause;
    private Button btnContinue;
    private Button btnNext;
    private TextView tvName;
    private ListView lstView;
    static int index;


    android.media.MediaPlayer mediaPlayer;
    ArrayList<String> lstName = new ArrayList<>();
    ArrayList<Uri> lstUri = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        btnPrev = findViewById(R.id.btnPrev);
        btnPause = findViewById(R.id.btnPause);
        btnContinue = findViewById(R.id.btnContinue);
        btnNext = findViewById(R.id.btnNext);
        tvName = findViewById(R.id.tvName);
        lstView = findViewById(R.id.lstView);

        btnContinue.setVisibility(View.GONE);

        getListRaw();// lay du lieu tu raw
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, lstName);
        lstView.setAdapter(arrayAdapter);

        lstView.setOnItemClickListener((adapterView, view, i, l) -> {
            try {
                mediaPlayer.reset();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String name = lstName.get(i);
            Uri uri2 = getRawUri(name);
            mediaPlayer = android.media.MediaPlayer.create(getApplicationContext(), uri2);
            mediaPlayer.start();
            index = i;
            tvName.setText(lstName.get(index));
        });
        btnPause.setOnClickListener(view -> {
            btnPause.setVisibility(View.GONE);
            try {
                btnContinue.setVisibility(View.VISIBLE);
                tvName.setText(lstName.get(index));
                mediaPlayer.pause();
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
        btnContinue.setOnClickListener(view -> {
            btnContinue.setVisibility(View.GONE);
            try {
                btnPause.setVisibility(View.VISIBLE);
                tvName.setText(lstName.get(index));
                mediaPlayer.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        btnNext.setOnClickListener(view -> {
            if (index == lstName.size()-1) {
                index = 0;
            } else {
                index++;
            }
            try {
                mediaPlayer.reset();
                tvName.setText(lstName.get(index));
            } catch (Exception e) {
                e.printStackTrace();
            }
            String name = lstName.get(index);
            Uri uri2 = getRawUri(name);
            mediaPlayer = android.media.MediaPlayer.create(getApplicationContext(), uri2);
            mediaPlayer.start();
        });
        btnPrev.setOnClickListener(view -> {
            if (index == 0) {
                index = lstName.size() - 1;
            } else {
                index--;
            }
            try {
                mediaPlayer.reset();
                tvName.setText(lstName.get(index));
            } catch (Exception e) {
                e.printStackTrace();
            }
            String name = lstName.get(index);
            Uri uri2 = getRawUri(name);
            mediaPlayer = android.media.MediaPlayer.create(getApplicationContext(), uri2);
            mediaPlayer.start();
        });
    }

    public void getListRaw() {
        Field[] fields = R.raw.class.getFields();
        for (int i = 0; i < fields.length; i++) {
            lstName.add(fields[i].getName());// them ten file nhac vao lst
            Uri uri1 = getRawUri(fields[i].getName());
            lstUri.add(uri1);
        }
    }

    public Uri getRawUri(String fileName) {
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                File.pathSeparator + File.separator + File.separator +
                getPackageName() + "/raw/" + fileName);
    }
}
